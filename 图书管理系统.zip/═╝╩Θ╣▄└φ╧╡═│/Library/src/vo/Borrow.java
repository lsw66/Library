package vo;

public class Borrow {
	
	private String Identifier;
	private String BookName;
	private String Time;
	private String Reader;
	private String IsReturn;
	private String ReturnTime;
	
	
	
	public Borrow(String identifier, String bookName, String time, String reader, String isReturn, String returnTime) {
		super();
		Identifier = identifier;
		BookName = bookName;
		Time = time;
		Reader = reader;
		IsReturn = isReturn;
		ReturnTime = returnTime;
	}
	public Borrow() {
		super();
	}
	public String getIdentifier() {
		return Identifier;
	}
	public void setIdentifier(String identifier) {
		Identifier = identifier;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	public String getReader() {
		return Reader;
	}
	public void setReader(String reader) {
		Reader = reader;
	}
	public String getIsReturn() {
		return IsReturn;
	}
	public void setIsReturn(String isReturn) {
		IsReturn = isReturn;
	}
	public String getReturnTime() {
		return ReturnTime;
	}
	public void setReturnTime(String returnTime) {
		ReturnTime = returnTime;
	}
	@Override
	public String toString() {
		return Identifier + "      " + BookName + "      " + Time + "       " + Reader
				+ "       " + IsReturn + "        " + ReturnTime ;
	}
	
	
	
	
}
