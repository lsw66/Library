package vo;

public class BookInformation {
	
	private String Identifier;
	private String BookName;
	private String Author;
	private String press;
	private int Total;
	private String isborrow;
	public BookInformation(String identifier, String bookName, String author, String press, int total,
			String isborrow) {
		super();
		Identifier = identifier;
		BookName = bookName;
		Author = author;
		this.press = press;
		this.Total = total;
		this.isborrow = isborrow;
	}
	public String getIdentifier() {
		return Identifier;
	}
	public void setIdentifier(String identifier) {
		Identifier = identifier;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	public String getPress() {
		return press;
	}
	public void setPress(String press) {
		this.press = press;
	}
	public int getTotal() {
		return Total;
	}
	public void setTotal(int total) {
		Total = total;
	}
	public String getIsborrow() {
		return isborrow;
	}
	public void setIsborrow(String isborrow) {
		this.isborrow = isborrow;
	}
	@Override
	public String toString() {
		return "BookInformation [Identifier=" + Identifier + ", BookName=" + BookName + ", Author=" + Author
				+ ", press=" + press + ", Total=" + Total + ", isborrow=" + isborrow + "]";
	}
	
	
}
