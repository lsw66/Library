package driver;

import service.service;
import vo.User;

public class test {
	public static void main(String [] args) throws Exception {
	//	User user=new User("������","456123", "����");
		service service=new service();
	//	service.readerMenu(user);
	//	service.BookMenu();
	//	service.UserMenu();
	//   service.borrowMenu();
		service.BigChoose();
		
	}
}
