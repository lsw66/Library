package driver;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import service.service;

class test2 {

	@Test
	void test() throws Exception {
		service service=new service();
		service.BigChoose();
	}

}
